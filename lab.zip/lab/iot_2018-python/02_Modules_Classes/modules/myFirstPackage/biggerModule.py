__all__=['f0']

def f0():
    return 

def f1():
    return 

def f2():
    return 

