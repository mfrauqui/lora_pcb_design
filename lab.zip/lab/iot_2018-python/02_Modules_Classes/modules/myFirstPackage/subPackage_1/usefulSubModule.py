def usefulFunction():
    return "I can use this usefulFunction"


