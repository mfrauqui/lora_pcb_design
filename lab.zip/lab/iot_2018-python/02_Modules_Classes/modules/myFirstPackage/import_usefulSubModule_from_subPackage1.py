import subPackage_1.usefulSubModule as sm

if __name__ == "__main__": 
    print(sm.usefulFunction())
