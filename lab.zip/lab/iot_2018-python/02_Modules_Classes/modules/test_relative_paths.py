import myFirstPackage.subPackage_2.needs_subPackage_1 as s

if __name__ == "__main__":
    print(s.f0())
