## Contents

- scopes and namespaces 
- comprehensions 
- generator comprehensions: next and yield keywords
- lambda and generic arguments functions
- modules and packages
  - how to import a module (basic usage)
  - how to make a module: structure of a module, run module as a script, intra-package ref
- classes
  - definition, special attributes
  - class/instance's methods/variables
  - special attributes and operator overloading 

