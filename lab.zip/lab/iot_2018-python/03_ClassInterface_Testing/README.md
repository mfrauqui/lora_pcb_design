## Contents

- inheritance, multiple inheritance and method resolution order
- super() built-in function

- decorators
- name conventions 
- data encapsulation
  - getter,setter,deleter
  - property and property decorations
- polymorhphism 
  - subtyping
  - duck typing 
  - abstract base classes
- context manager and contextlib
- iterable, sequence, iterator
- unittest TestCase

