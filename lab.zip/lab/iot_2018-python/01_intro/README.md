## Contents

- how to use python:
  - interactively (shell, jupyter)
  - script (...)
- identifiers, keywords, operators
- literals, compund data structures (i.e., tuple, list, set, dict)
- control flow tools (i.e., conditional, loops, reminder, context, exceptions)
  - special looping functions (i.e., reversed,zip,enumerate,sorted)
- definition of a function
  - keyword arguments
  - positional arguments  
  - lambda expressions
  - function annotations

